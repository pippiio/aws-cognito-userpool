exports.handler = (event, context, callback) => {
    console.log(event.triggerSource);
    console.log(event.request);

    let signupEvent = {"emailMessage":"Hej!\n\nDu har nu registrerat dig via den kod som du fått. Och den personen som gett dig koden kan nu även följa din progress i utbildningen. \u003ca href=\"https://nsph-stage.dimh-test.com/verification/{email}/{code}\"\u003eKlicka här för att verifiera din email\u003c/a\u003e","emailSubject":"Välkommen","smsMessage":null};
    let adminCreateUserEvent = {"emailMessage":null,"emailSubject":null,"smsMessage":null};
    let resendCodeEvent = {"emailMessage":null,"emailSubject":null,"smsMessage":null};
    let forgotPasswordEvent = {"emailMessage":"Hej!\n\n\u003ca href=\"https://nsph-stage.dimh-test.com/restorePassword/{token}\"\u003eKlicka här för att återställa ditt lösenord.\u003c/a\u003e\n\nAnvänd koden {code}\n\nOm du inte kan öppna länken, vänligen kopiera länken. Försök därefter klistra in och öppna i annan webbläsare.","emailSubject":"Lösenord återställning","smsMessage":null};
    let updateUserAttributeEvent = {"emailMessage":null,"emailSubject":null,"smsMessage":null};
    let verifyUserAttributeEvent = {"emailMessage":null,"emailSubject":null,"smsMessage":null};
    let authenticationEvent = {"emailMessage":null,"emailSubject":null,"smsMessage":null};

    switch (event.triggerSource) {
        case "CustomMessage_SignUp":
            event.response = signupEvent;
            break;
        case "CustomMessage_AdminCreateUser":
            event.response = adminCreateUserEvent;
            break;
        case "CustomMessage_ResendCode":
            event.response = resendCodeEvent;
            break;
        case "CustomMessage_ForgotPassword":
            event.response = forgotPasswordEvent;
            break;
        case "CustomMessage_UpdateUserAttribute":
            event.response = updateUserAttributeEvent;
            break;
        case "CustomMessage_VerifyUserAttribute":
            event.response = verifyUserAttributeEvent;
            break;
        case "CustomMessage_Authentication":
            event.response = authenticationEvent;
            break;
    }

    let email = event.request.userAttributes.email;
    let username = event.request.usernameParameter;
    let code = event.request.codeParameter;
    let token = event.request.clientMetadata != null && event.request.clientMetadata.token != null ? event.request.clientMetadata.token : "";

    for (var property in event.response) {
        if (Object.prototype.hasOwnProperty.call(event.response, property) && event.response[property] != null) {
            event.response[property] = event.response[property]
                .replace("{email}", email)
                .replace("{username}", username)
                .replace("{token}", token)
                .replace("{code}", code);
        }
    }

    console.log(event.response);
    callback(null, event);
};
